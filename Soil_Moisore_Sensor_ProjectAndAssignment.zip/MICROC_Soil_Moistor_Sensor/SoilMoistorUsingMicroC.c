// LCD module connections
sbit LCD_RS at RC0_bit;
sbit LCD_EN at RC1_bit;
sbit LCD_D4 at RC2_bit;
sbit LCD_D5 at RC3_bit;
sbit LCD_D6 at RC4_bit;
sbit LCD_D7 at RC5_bit;

sbit LCD_RS_Direction at TRISC0_bit;
sbit LCD_EN_Direction at TRISC1_bit;
sbit LCD_D4_Direction at TRISC2_bit;
sbit LCD_D5_Direction at TRISC3_bit;
sbit LCD_D6_Direction at TRISC4_bit;
sbit LCD_D7_Direction at TRISC5_bit;


////// Moisture sensor variable///////
float moisture_value;
char text[10];

void main(void)
{
    ADC_Init();             // Initialize the ADC module of PIC16F877A microcontroller
    Lcd_Init();             // Initialize the LCD
    Lcd_Cmd(_LCD_CLEAR);    // Clear the display
    Lcd_Cmd(_LCD_CURSOR_OFF); // Turn off the cursor
    Lcd_Out(1, 1, "MOISTURE SENSOR"); // Display text on the first row


    while (1)
    {
        // Read moisture value from the sensor
        moisture_value = ADC_Read(0);
        moisture_value = (moisture_value * 100) / 1023; // Convert the moisture value to a percentage

        // Convert the moisture value to string
        FloatToStr(moisture_value, Ltrim(text));

        Lcd_Out(2, 1, text);    // Display the moisture value
        Lcd_Out_cp("%");
        Delay_ms(1000);


    }
}